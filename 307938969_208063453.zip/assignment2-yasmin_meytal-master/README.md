# Assignment2
 
Website address: https://sise-web-development-environments.github.io/assignment2-yasmin_meytal/

Added functionality:

Extra time- an icon of a clock that moves randomly on the game board and add 20 seconds to the game time.

Sour candy- an icon of a yellow candy that placed at a random cell on the board and drops 20 points form the score.

About us:

The game designed by Meytal Yaniv & Yasmin Avraham as part of Web Development Environments course.

Meytal Yaniv: ID - 307938969  
Email: meshumey@post.bgu.ac.il

Yasmin Avraham: ID - 208063453
Email:  yasminav@post.bgu.ac.il 
